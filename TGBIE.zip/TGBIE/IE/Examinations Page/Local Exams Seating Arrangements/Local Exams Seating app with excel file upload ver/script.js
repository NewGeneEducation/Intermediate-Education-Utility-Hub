 // 1. Block Context Menu
    document.addEventListener('contextmenu', e => e.preventDefault());

    // 2. Block Keyboard Inspection Shortcuts
    document.addEventListener('keydown', function(e) {
      if (e.key === 'F12' || e.keyCode === 123) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'i' || e.key === 'I' || e.keyCode === 73)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'j' || e.key === 'J' || e.keyCode === 74)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'c' || e.key === 'C' || e.keyCode === 67)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) { e.preventDefault(); return false; }
    });

    // 3. DevTools Debugger Trap (Freezes execution if DevTools is forced open)
    (function antiDebug() {
      setInterval(function() {
        const start = Date.now();
        (function() {}["constructor"]("debugger")());
        if (Date.now() - start > 100) {
          document.body.innerHTML = '<h2 style="color:red;text-align:center;margin-top:20%;">Developer Tools are restricted. Please close the console and reload.</h2>';
        }
      }, 1000);
    })();




const GROUP_COLORS = [
    '#2563eb', '#059669', '#dc2626', '#7c3aed',
    '#ea580c', '#0284c7', '#0d9488', '#4f46e5',
    '#db2777', '#ca8a04', '#475569', '#9333ea'
];

const VALID_GROUPS = ['MPC', 'BPC', 'CEC', 'HEC', 'ET', 'MPHW(F)'];

let students1stData = [];
let students2ndData = [];

const PRESET_1ST = [
    { name: "John Doe", group: "MPC", lang: "G.F.C" },
    { name: "Alice Smith", group: "MPC", lang: "G.F.C" },
    { name: "Emma Watson", group: "BPC", lang: "Telugu" },
    { name: "David Miller", group: "CEC", lang: "Hindi" }
];

const PRESET_2ND = [
    { name: "Ethan Hunt", group: "MPC", lang: "G.F.C" },
    { name: "Sophia Loren", group: "BPC", lang: "Telugu" },
    { name: "James Bond", group: "HEC", lang: "Hindi" },
    { name: "Diana Prince", group: "ET", lang: "G.F.C" }
];

window.onload = function() {
    loadSavedTheme();
    if (!loadFromLocalStorage()) {
        loadDefaultData();
    }
};

function goHome() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    const layoutArea = document.getElementById('layoutArea');
    if (layoutArea) layoutArea.style.display = 'none';
}

function changeTheme(themeName) {
    document.documentElement.setAttribute('data-theme', themeName);
    localStorage.setItem('examEngine_theme', themeName);
}

function loadSavedTheme() {
    const savedTheme = localStorage.getItem('examEngine_theme') || 'executive';
    document.documentElement.setAttribute('data-theme', savedTheme);
    document.getElementById('themeSelect').value = savedTheme;
}

function loadDefaultData() {
    document.getElementById('roomTableBody').innerHTML = '';
    for (let r = 1; r <= 2; r++) {
        addRoomTableRow(`Room 10${r}`, [3, 3], false);
    }

    students1stData = [...PRESET_1ST];
    students2ndData = [...PRESET_2ND];
    
    sortAndRenderStudents();
    saveToLocalStorage();
}

function saveToLocalStorage() {
    const roomsData = [];
    document.querySelectorAll('#roomTableBody tr').forEach(row => {
        const name = row.querySelector('.rm-name').value;
        const cols = [];
        row.querySelectorAll('.col-benches').forEach(input => cols.push(parseInt(input.value) || 0));
        roomsData.push({ name, cols });
    });

    localStorage.setItem('examEngine_rooms', JSON.stringify(roomsData));
    localStorage.setItem('examEngine_stud1st', JSON.stringify(students1stData));
    localStorage.setItem('examEngine_stud2nd', JSON.stringify(students2ndData));
    showSaveStatus();
}

function loadFromLocalStorage() {
    const savedRooms = localStorage.getItem('examEngine_rooms');
    const saved1st = localStorage.getItem('examEngine_stud1st');
    const saved2nd = localStorage.getItem('examEngine_stud2nd');

    if (!savedRooms && !saved1st && !saved2nd) return false;

    if (savedRooms) {
        const roomsData = JSON.parse(savedRooms);
        document.getElementById('roomTableBody').innerHTML = '';
        roomsData.forEach(r => addRoomTableRow(r.name, r.cols, false));
    }

    if (saved1st) students1stData = JSON.parse(saved1st);
    if (saved2nd) students2ndData = JSON.parse(saved2nd);

    sortAndRenderStudents();
    return true;
}

function showSaveStatus() {
    const badge = document.getElementById('saveStatus');
    if (badge) {
        badge.style.opacity = '1';
        setTimeout(() => { badge.style.opacity = '0'; }, 1200);
    }
}

function resetToDefaults() {
    if (confirm('Reset rooms and student data to defaults?')) {
        localStorage.removeItem('examEngine_rooms');
        localStorage.removeItem('examEngine_stud1st');
        localStorage.removeItem('examEngine_stud2nd');
        loadDefaultData();
    }
}

// Sort students group-wise: MPC, BPC, CEC, HEC, ET, MPHW(F)
function sortAndRenderStudents() {
    const groupPriority = { 'MPC': 1, 'BPC': 2, 'CEC': 3, 'HEC': 4, 'ET': 5, 'MPHW(F)': 6 };

    const sortByGroup = (a, b) => {
        let pA = groupPriority[a.group.toUpperCase()] || 99;
        let pB = groupPriority[b.group.toUpperCase()] || 99;
        if (pA !== pB) return pA - pB;
        return a.name.localeCompare(b.name);
    };

    students1stData.sort(sortByGroup);
    students2ndData.sort(sortByGroup);

    renderTableRows('table1st', students1stData);
    renderTableRows('table2nd', students2ndData);

    document.getElementById('count1st').value = students1stData.length;
    document.getElementById('count2nd').value = students2ndData.length;
    saveToLocalStorage();
}

function renderTableRows(tableId, dataList) {
    const tbody = document.querySelector(`#${tableId} tbody`);
    tbody.innerHTML = '';
    if (dataList.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: #64748b; font-style: italic;">No student data available</td></tr>`;
        return;
    }

    dataList.forEach((s) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><span style="background: var(--bench-bg); padding: 2px 6px; border-radius: 4px; font-weight:700;">${s.group}</span></td>
            <td><strong>${s.name}</strong></td>
            <td>${s.lang}</td>
        `;
        tbody.appendChild(tr);
    });
}

// Parse uploaded Excel / CSV files mapping G.F.C correctly
async function handleExcelUpload(event, yearType) {
    const file = event.target.files[0];
    if (!file) return;

    try {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data, { type: 'array' });
        
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        
        let parsedRecords = [];
        
        rows.forEach((row) => {
            if (!row || row.length === 0) return;
            
            let tokens = row.map(cell => String(cell).trim()).filter(c => c !== '');
            if (tokens.length >= 1) {
                let textJoined = ' ' + tokens.join(' ').toUpperCase() + ' ';
                
                let detectedGroup = 'MPC';
                for (let g of VALID_GROUPS) {
                    if (textJoined.includes(' ' + g + ' ') || textJoined.includes(g)) {
                        detectedGroup = g;
                        break;
                    }
                }

                // Explicitly maps G.F.C instead of fallback languages
                let detectedLang = 'G.F.C';
                if (textJoined.includes('TELUGU')) {
                    detectedLang = 'Telugu';
                } else if (textJoined.includes('HINDI')) {
                    detectedLang = 'Hindi';
                } else if (textJoined.includes('URDU')) {
                    detectedLang = 'Urdu';
                } else if (textJoined.includes('SANSKRIT')) {
                    detectedLang = 'Sanskrit';
                } else if (textJoined.includes('G.F.C') || textJoined.includes('GFC')) {
                    detectedLang = 'G.F.C';
                }

                let nameTokens = tokens.filter(t => !VALID_GROUPS.includes(t.toUpperCase()) && !['TELUGU','HINDI','URDU','SANSKRIT','ENGLISH','G.F.C','GFC'].includes(t.toUpperCase()) && !/^\d+$/.test(t));
                let name = nameTokens.length > 0 ? nameTokens.join(' ') : tokens[0];

                if (name.toUpperCase() !== 'NAME' && name.toUpperCase() !== 'STUDENT NAME') {
                    parsedRecords.push({
                        name: name,
                        group: detectedGroup,
                        lang: detectedLang
                    });
                }
            }
        });

        if (parsedRecords.length > 0) {
            if (yearType === '1') {
                students1stData = parsedRecords;
            } else {
                students2ndData = parsedRecords;
            }
            sortAndRenderStudents();
            alert(`${yearType === '1' ? '1st' : '2nd'} Year Excel file successfully parsed with G.F.C recognized correctly and sorted group-wise!`);
        } else {
            alert('No valid student records found in the uploaded Excel file.');
        }
    } catch (error) {
        console.error('Error parsing Excel file:', error);
        alert('Failed to read Excel file. Please ensure it is a valid .xlsx, .xls, or .csv file.');
    } finally {
        event.target.value = '';
    }
}

function addRoomTableRow(roomName = '', defaultCols = [3, 3], triggerSave = true) {
    const tbody = document.getElementById('roomTableBody');
    const rowCount = tbody.rows.length + 1;
    const row = document.createElement('tr');
    const roomTitle = roomName || `Room 10${rowCount}`;

    row.innerHTML = `
        <td><input type="text" class="rm-name" value="${roomTitle}" placeholder="e.g. Hall A"></td>
        <td>
            <div class="cols-config-container">
                <div class="cols-list" style="display: flex; gap: 4px; flex-wrap: wrap;"></div>
                <button class="btn-sm-add" onclick="addColumnToRoom(this)">+ Col</button>
            </div>
        </td>
        <td style="text-align: center;"><button class="btn-remove" onclick="removeRowAndSave(this)">✕</button></td>
    `;

    tbody.appendChild(row);
    const colsList = row.querySelector('.cols-list');
    defaultCols.forEach((benchCount, idx) => createColumnBadge(colsList, idx + 1, benchCount));
    if (triggerSave) saveToLocalStorage();
}

function createColumnBadge(container, colNum, benchCount) {
    const div = document.createElement('div');
    div.className = 'col-bench-unit';
    div.innerHTML = `
        <span>C<span class="col-idx">${colNum}</span>:</span>
        <input type="number" class="col-benches" value="${benchCount}" min="1">
        <span style="cursor: pointer; color: #ef4444; font-weight: bold; margin-left: 2px;" onclick="removeColumnFromRoom(this)">✕</span>
    `;
    container.appendChild(div);
}

function addColumnToRoom(btn) {
    const colsList = btn.previousElementSibling;
    const colNum = colsList.children.length + 1;
    createColumnBadge(colsList, colNum, 3);
    saveToLocalStorage();
}

function removeColumnFromRoom(crossBtn) {
    const colsList = crossBtn.closest('.cols-list');
    crossBtn.closest('.col-bench-unit').remove();
    Array.from(colsList.children).forEach((child, idx) => {
        child.querySelector('.col-idx').innerText = idx + 1;
    });
    saveToLocalStorage();
}

function removeRowAndSave(btn) {
    btn.closest('tr').remove();
    saveToLocalStorage();
}

function groupStudentsForSeating(studentList, yearLabel) {
    const map = {};
    studentList.forEach(s => {
        let streamKey = `${yearLabel} ${s.group}`;
        if (!map[streamKey]) map[streamKey] = [];
        map[streamKey].push(`${s.name} (${s.lang})`);
    });

    const groups = [];
    let colorIdx = 0;
    for (const [streamName, students] of Object.entries(map)) {
        groups.push({
            name: streamName,
            stream: streamName,
            students: students,
            color: GROUP_COLORS[colorIdx % GROUP_COLORS.length],
            pointer: 0
        });
        colorIdx++;
    }
    return groups;
}

function generateSeating() {
    const roomRows = document.querySelectorAll('#roomTableBody tr');
    const rooms = [];
    let totalRoomCapacity = 0;
    let totalBenchesRoom = 0;

    roomRows.forEach((row, idx) => {
        const name = row.querySelector('.rm-name').value.trim() || `Room ${idx + 1}`;
        const benchInputs = row.querySelectorAll('.col-benches');
        const colBenches = [];
        benchInputs.forEach(input => {
            const count = parseInt(input.value) || 0;
            if (count > 0) colBenches.push(count);
        });

        if (colBenches.length > 0) {
            const roomBenchCount = colBenches.reduce((a, b) => a + b, 0);
            const capacity = roomBenchCount * 2;
            rooms.push({ name: name, columns: colBenches, totalBenches: roomBenchCount, capacity: capacity });
            totalBenchesRoom += roomBenchCount;
            totalRoomCapacity += capacity;
        }
    });

    if (rooms.length === 0) {
        alert('Please add at least one valid room with columns.');
        return;
    }

    const firstYrGroups = groupStudentsForSeating(students1stData, '1st');
    const secondYrGroups = groupStudentsForSeating(students2ndData, '2nd');
    const allGroupsLegend = [...firstYrGroups, ...secondYrGroups];

    const total1stYrStudents = students1stData.length;
    const total2ndYrStudents = students2ndData.length;

    if (total1stYrStudents === 0 && total2ndYrStudents === 0) {
        alert('Please provide 1st Year or 2nd Year student records.');
        return;
    }

    const legendContainer = document.getElementById('legendContainer');
    legendContainer.innerHTML = allGroupsLegend.map(g => `
        <div class="legend-item">
            <div class="legend-box" style="background: ${g.color};"></div> ${g.name}: ${g.students.length}
        </div>
    `).join('') + `
        <div class="legend-item">
            <div class="legend-box" style="background: #e2e8f0;"></div> Empty
        </div>
    `;

    document.getElementById('infoBar').innerHTML = `
        <div class="info-card">Rooms: ${rooms.length}</div>
        <div class="info-card">Benches: ${totalBenchesRoom}</div>
        <div class="info-card">Capacity: ${totalRoomCapacity} Seats</div>
        <div class="info-card">1st Yr (Left): ${total1stYrStudents}</div>
        <div class="info-card">2nd Yr (Right): ${total2ndYrStudents}</div>
    `;

    const roomsOutputContainer = document.getElementById('roomsOutputContainer');
    roomsOutputContainer.innerHTML = '';

    let turn1stYr = 0;
    let turn2ndYr = 0;

    rooms.forEach((room) => {
        const roomBlock = document.createElement('div');
        roomBlock.className = 'room-block';
        roomBlock.innerHTML = `
            <div class="room-title">${room.name}</div>
            <div class="blackboard">BLACKBOARD / FRONT</div>
        `;

        const classroomGrid = document.createElement('div');
        classroomGrid.className = 'classroom-grid';
        let globalBenchCount = 1;

        room.columns.forEach((benchCount, cIdx) => {
            const colNum = cIdx + 1;
            const columnDiv = document.createElement('div');
            columnDiv.className = 'column';

            const colHeader = document.createElement('div');
            colHeader.className = 'column-header';
            colHeader.innerText = `Col ${colNum} (${benchCount} Benches)`;
            columnDiv.appendChild(colHeader);

            for (let b = 1; b <= benchCount; b++) {
                const bench = document.createElement('div');
                bench.className = 'bench';

                const benchNum = document.createElement('div');
                benchNum.className = 'bench-number';
                benchNum.innerText = `C${colNum}-B${b} (#${globalBenchCount})`;
                bench.appendChild(benchNum);

                const seatsContainer = document.createElement('div');
                seatsContainer.className = 'seats-container';

                for (let s = 1; s <= 2; s++) {
                    const seat = document.createElement('div');
                    seat.className = 'seat';

                    const isLeft = (s === 1);
                    const activeGroups = isLeft ? firstYrGroups : secondYrGroups;
                    let turnIndex = isLeft ? turn1stYr : turn2ndYr;
                    let assigned = false;

                    if (activeGroups.length > 0) {
                        for (let attempts = 0; attempts < activeGroups.length; attempts++) {
                            const targetIdx = (turnIndex + attempts) % activeGroups.length;
                            const group = activeGroups[targetIdx];

                            if (group.pointer < group.students.length) {
                                const studentVal = group.students[group.pointer];
                                group.pointer++;

                                seat.innerHTML = `
                                    <span class="seat-group-tag">${group.stream}</span>
                                    <span class="seat-student-name">${studentVal}</span>
                                `;
                                seat.style.backgroundColor = group.color;

                                if (isLeft) turn1stYr = (targetIdx + 1) % activeGroups.length;
                                else turn2ndYr = (targetIdx + 1) % activeGroups.length;

                                assigned = true;
                                break;
                            }
                        }
                    }

                    if (!assigned) {
                        seat.innerHTML = `
                            <span class="seat-group-tag">${isLeft ? '1ST YR' : '2ND YR'}</span>
                            <span class="seat-student-name">Empty</span>
                        `;
                        seat.classList.add('empty');
                    }

                    seatsContainer.appendChild(seat);
                }

                bench.appendChild(seatsContainer);
                columnDiv.appendChild(bench);
                globalBenchCount++;
            }

            classroomGrid.appendChild(columnDiv);
        });

        roomBlock.appendChild(classroomGrid);
        roomsOutputContainer.appendChild(roomBlock);
    });

    const layoutArea = document.getElementById('layoutArea');
    layoutArea.style.display = 'block';
    layoutArea.scrollIntoView({ behavior: 'smooth' });
}