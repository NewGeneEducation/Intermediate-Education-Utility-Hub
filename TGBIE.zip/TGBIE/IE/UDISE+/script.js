/* =========================================================
   INDEXEDDB STORAGE HELPER ENGINE
   ========================================================= */
const dbHelper = {
    dbName: 'UDISE_Dashboard_DB',
    dbVersion: 1,
    storeName: 'app_data',
    db: null,

    open() {
        return new Promise((resolve, reject) => {
            if (this.db) return resolve(this.db);
            const req = indexedDB.open(this.dbName, this.dbVersion);
            req.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) {
                    db.createObjectStore(this.storeName);
                }
            };
            req.onsuccess = (e) => {
                this.db = e.target.result;
                resolve(this.db);
            };
            req.onerror = (e) => reject(e.target.error);
        });
    },

    async setItem(key, value) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction([this.storeName], 'readwrite');
            const store = tx.objectStore(this.storeName);
            const req = store.put(value, key);
            req.onsuccess = () => resolve();
            req.onerror = (e) => reject(e.target.error);
        });
    },

    async getItem(key) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction([this.storeName], 'readonly');
            const store = tx.objectStore(this.storeName);
            const req = store.get(key);
            req.onsuccess = () => resolve(req.result !== undefined ? req.result : null);
            req.onerror = (e) => reject(e.target.error);
        });
    },

    async removeItem(key) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction([this.storeName], 'readwrite');
            const store = tx.objectStore(this.storeName);
            const req = store.delete(key);
            req.onsuccess = () => resolve();
            req.onerror = (e) => reject(e.target.error);
        });
    },

    async clear() {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction([this.storeName], 'readwrite');
            const store = tx.objectStore(this.storeName);
            const req = store.clear();
            req.onsuccess = () => resolve();
            req.onerror = (e) => reject(e.target.error);
        });
    }
};

let fileInput = null;
let dropZone = null;
let fileNameDisplay = null;

let globalStudents = [];
let currentFilteredList = [];
let currentFilterTitle = '';

let rawDataUdise = null;
let uploadedUdiseCode = '';

window.addEventListener('DOMContentLoaded', async () => {
    fileInput = document.getElementById('fileInput');
    dropZone = document.getElementById('dropZone');
    fileNameDisplay = document.getElementById('fileNameDisplay');

    try {
        const [savedUdise, savedUdiseName, code] = await Promise.all([
            dbHelper.getItem('udise_active_data'),
            dbHelper.getItem('udise_active_name'),
            dbHelper.getItem('udise_college_code')
        ]);

        uploadedUdiseCode = code || '';

        if (savedUdise && document.getElementById('pageDashboard')) {
            rawDataUdise = savedUdise;
            if (fileNameDisplay) fileNameDisplay.textContent = savedUdiseName || 'Active_Students.xlsx';
            uploadedUdiseCode = extractUdiseCodeFromRows(rawDataUdise);
            processUDISEData(rawDataUdise, savedUdiseName || 'Active_Students.xlsx', false);
        }
    } catch (e) {
        console.error("IndexedDB Initialization Error:", e);
    }

    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });
        dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) handleFile(e.dataTransfer.files[0]);
        });
    }

    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) handleFile(e.target.files[0]);
        });
    }
});

async function clearAllData() {
    if (!confirm("Are you sure you want to clear all uploaded data?")) return;

    try {
        await dbHelper.clear();
    } catch(e) {
        console.error("Failed to clear IndexedDB:", e);
    }

    globalStudents = [];
    currentFilteredList = [];
    currentFilterTitle = '';
    rawDataUdise = null;
    uploadedUdiseCode = '';

    if (fileInput) fileInput.value = '';
    if (fileNameDisplay) fileNameDisplay.textContent = 'No file chosen';

    const penInput = document.getElementById('penSearchInput');
    if (penInput) penInput.value = '';

    document.getElementById('reportSub').innerHTML = 'Academic Session &amp; School Report';
    document.getElementById('classesBadge').textContent = 'Classes: -';
    document.getElementById('totalActiveBadge').textContent = 'Total: 0';

    document.getElementById('kpiTotal').textContent = '0';
    document.getElementById('kpiBoys').textContent = '0';
    document.getElementById('kpiBoysPct').textContent = '0% of total';
    document.getElementById('kpiGirls').textContent = '0';
    document.getElementById('kpiGirlsPct').textContent = '0% of total';
    document.getElementById('kpiAadhaar').textContent = '0';
    document.getElementById('kpiAadhaarPct').textContent = '0% verified';
    document.getElementById('kpiMbuPending').textContent = '0';
    document.getElementById('kpiMbuPendingPct').textContent = '0% pending';
    document.getElementById('kpiApaar').textContent = '0';
    document.getElementById('kpiApaarPct').textContent = '0% generated';
    document.getElementById('kpiBpl').textContent = '0';
    document.getElementById('kpiBplPct').textContent = '0% eligible';

    document.getElementById('classSectionTableBody').innerHTML = `
        <tr>
            <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 16px;">No student records loaded. Upload an Excel file above to populate class details.</td>
        </tr>
        <tr class="total-row">
            <td colspan="2">Grand Total</td>
            <td><div class="cell-flex"><span>0</span><button class="btn-text-list no-print" onclick="filterAndShow('All Boys', s => isMale(s))">List</button></div></td>
            <td><div class="cell-flex"><span>0</span><button class="btn-text-list no-print" onclick="filterAndShow('All Girls', s => isFemale(s))">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button></div></td>
        </tr>`;

    document.getElementById('mbuSummaryTableBody').innerHTML = `
        <tr>
            <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 16px;">No class data available.</td>
        </tr>
        <tr class="total-row">
            <td>Grand Total</td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All MBU Pending', s => getMbuKey(s) === 'pending')">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All MBU Completed', s => getMbuKey(s) === 'completed')">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All MBU N/A', s => getMbuKey(s) === 'not_required')">List</button></div></td>
            <td><strong>0.0%</strong></td>
        </tr>`;

    const mbuBadge = document.getElementById('mbuOverallBadge');
    if (mbuBadge) {
        mbuBadge.textContent = '0/0 (0.0%)';
        mbuBadge.className = 'status-pill status-neutral';
    }

    document.getElementById('apaarSummaryTableBody').innerHTML = `
        <tr>
            <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 16px;">No class data available.</td>
        </tr>
        <tr class="total-row">
            <td>Grand Total</td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Generated', s => isApaarDone(s))">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Pending', s => !isApaarDone(s))">List</button></div></td>
            <td><strong>0.0%</strong></td>
        </tr>`;

    const apaarBadge = document.getElementById('apaarOverallBadge');
    if (apaarBadge) {
        apaarBadge.textContent = '0/0 (0.0%)';
        apaarBadge.className = 'status-pill status-neutral';
    }

    document.getElementById('apaarAadhaarTableBody').innerHTML = `
        <tr>
            <td><span class="status-pill status-verified">Verified</span></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Verified Students', s => getAadhaarKey(s) === 'Verified')">List</button></div></td>
            <td><div class="cell-flex"><span class="status-pill status-verified">0 Generated</span><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Verified &amp; APAAR Generated', s => getAadhaarKey(s) === 'Verified' && isApaarDone(s))">List</button></div></td>
            <td><div class="cell-flex"><span class="status-pill status-pending">0 Pending</span><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Verified &amp; APAAR Pending', s => getAadhaarKey(s) === 'Verified' && !isApaarDone(s))">List</button></div></td>
            <td><strong>0.0%</strong></td>
        </tr>
        <tr>
            <td><span class="status-pill status-failed">Validation failed</span></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Validation failed Students', s => getAadhaarKey(s) === 'Validation failed')">List</button></div></td>
            <td><div class="cell-flex"><span class="status-pill status-verified">0 Generated</span><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Failed &amp; APAAR Generated', s => getAadhaarKey(s) === 'Validation failed' && isApaarDone(s))">List</button></div></td>
            <td><div class="cell-flex"><span class="status-pill status-pending">0 Pending</span><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Failed &amp; APAAR Pending', s => getAadhaarKey(s) === 'Validation failed' && !isApaarDone(s))">List</button></div></td>
            <td><strong>0.0%</strong></td>
        </tr>
        <tr>
            <td><span class="status-pill status-pending">Pending</span></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Pending Students', s => getAadhaarKey(s) === 'Pending')">List</button></div></td>
            <td><div class="cell-flex"><span class="status-pill status-verified">0 Generated</span><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Pending &amp; APAAR Generated', s => getAadhaarKey(s) === 'Pending' && isApaarDone(s))">List</button></div></td>
            <td><div class="cell-flex"><span class="status-pill status-pending">0 Pending</span><button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar Pending &amp; APAAR Pending', s => getAadhaarKey(s) === 'Pending' && !isApaarDone(s))">List</button></div></td>
            <td><strong>0.0%</strong></td>
        </tr>
        <tr class="total-row">
            <td>Grand Total</td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Generated', s => isApaarDone(s))">List</button></div></td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Pending', s => !isApaarDone(s))">List</button></div></td>
            <td><strong>0.0%</strong></td>
        </tr>`;

    document.getElementById('socialCategoryTableHead').innerHTML = `<tr><th>Category</th><th>Total</th></tr>`;
    document.getElementById('socialCategoryTableBody').innerHTML = `
        <tr>
            <td colspan="2" style="text-align: center; color: var(--text-muted); padding: 16px;">No categories detected yet.</td>
        </tr>
        <tr class="total-row">
            <td>Grand Total</td>
            <td><div class="cell-flex"><strong>0</strong><button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button></div></td>
        </tr>`;

    document.getElementById('complianceTableBody').innerHTML = `
        <tr><td><strong>Aadhaar Verified</strong></td><td><strong>0</strong></td><td><span class="status-pill status-verified">Verified</span></td><td class="no-print"><button class="btn-text-list" onclick="filterAndShow('Aadhaar Verified Students', s => getAadhaarKey(s) === 'Verified')">List</button></td></tr>
        <tr><td><strong>Aadhaar Failed</strong></td><td><strong>0</strong></td><td><span class="status-pill status-failed">Failed</span></td><td class="no-print"><button class="btn-text-list" onclick="filterAndShow('Aadhaar Failed Students', s => getAadhaarKey(s) === 'Validation failed')">List</button></td></tr>
        <tr><td><strong>Aadhaar Pending</strong></td><td><strong>0</strong></td><td><span class="status-pill status-pending">Pending</span></td><td class="no-print"><button class="btn-text-list" onclick="filterAndShow('Aadhaar Pending Students', s => getAadhaarKey(s) === 'Pending')">List</button></td></tr>
        <tr><td><strong>MBU Pending</strong></td><td><strong>0 / 0</strong></td><td><span class="status-pill status-verified">0.0% Pending</span></td><td class="no-print"><button class="btn-text-list" onclick="filterAndShow('MBU Pending Students', s => getMbuKey(s) === 'pending')">List</button></td></tr>
        <tr><td><strong>CWSN Students</strong></td><td><strong>0</strong></td><td>Recorded</td><td class="no-print"><button class="btn-text-list" onclick="filterAndShow('CWSN Students', s => (s['CWSN']||'').toLowerCase() === 'yes')">List</button></td></tr>
        <tr><td><strong>BPL Beneficiaries</strong></td><td><strong>0 / 0</strong></td><td>0.0% Eligible</td><td class="no-print"><button class="btn-text-list" onclick="filterAndShow('BPL Beneficiaries', s => (s['BPL beneficiary']||'').toLowerCase() === 'yes')">List</button></td></tr>
        <tr class="total-row"><td><strong>Entry Status Done</strong></td><td><strong>0 / 0</strong></td><td>0 Incomplete</td><td class="no-print"><button class="btn-text-list btn-list-primary" onclick="filterAndShow('Completed Entries', s => (s['Entry Status']||'').toLowerCase().includes('completed'))">List</button></td></tr>`;
}

function updateLiveDateTime() {
    const now = new Date();
    const options = { weekday: 'short', year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
    const el = document.getElementById('currentLiveDateTime');
    if (el) el.textContent = now.toLocaleString('en-IN', options);
}
updateLiveDateTime();
setInterval(updateLiveDateTime, 1000);

function openHelpGuideModal() {
    document.getElementById('helpGuideModal').style.display = 'flex';
}

function closeHelpGuideModal() {
    document.getElementById('helpGuideModal').style.display = 'none';
}

function closeHelpModalOnOutside(e) {
    if (e.target.id === 'helpGuideModal') closeHelpGuideModal();
}

function handleFile(file) {
    if (typeof XLSX === 'undefined') {
        alert('Excel parser library is still loading. Please check your internet connection.');
        return;
    }

    fileNameDisplay.textContent = file.name;
    const reader = new FileReader();

    reader.onload = async (e) => {
        try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array', cellDates: true });
            const worksheet = workbook.Sheets[workbook.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            
            await dbHelper.setItem('udise_active_data', rows);
            await dbHelper.setItem('udise_active_name', file.name);

            uploadedUdiseCode = extractUdiseCodeFromRows(rows);
            if (uploadedUdiseCode) {
                await dbHelper.setItem('udise_college_code', uploadedUdiseCode);
            } else {
                await dbHelper.removeItem('udise_college_code');
            }

            processUDISEData(rows, file.name, true);
        } catch (err) {
            console.error(err);
            alert('Error processing file. Please ensure it is a valid Excel spreadsheet.');
        }
    };
    reader.readAsArrayBuffer(file);
}

function extractUdiseCodeFromRows(rows) {
    if (!Array.isArray(rows) || !rows.length) return '';

    const clean = v => String(v ?? '').trim();
    const normal = v => clean(v).toLowerCase().replace(/[\s_+.-]+/g, '');
    const isCode = v => {
        const x = clean(v).replace(/\.0$/, '');
        return /^\d{10,12}$/.test(x);
    };

    for (let r = 0; r < Math.min(rows.length, 40); r++) {
        const row = Array.isArray(rows[r]) ? rows[r] : [];
        for (let c = 0; c < row.length; c++) {
            const label = normal(row[c]);
            if (label.includes('udise') && label.includes('code')) {
                for (let k = c + 1; k < Math.min(c + 4, row.length); k++) {
                    if (isCode(row[k])) return clean(row[k]).replace(/\.0$/, '');
                }
                if (r + 1 < rows.length) {
                    const next = Array.isArray(rows[r + 1]) ? rows[r + 1] : [];
                    for (const v of next) if (isCode(v)) return clean(v).replace(/\.0$/, '');
                }
            }
        }
    }

    for (let r = 0; r < Math.min(rows.length, 15); r++) {
        const row = Array.isArray(rows[r]) ? rows[r] : [];
        const idx = row.findIndex(v => {
            const n = normal(v);
            return n === 'udisecode' || n === 'schooludisecode' || n === 'collegeudisecode' || (n.includes('udise') && n.includes('code'));
        });
        if (idx >= 0) {
            for (let rr = r + 1; rr < Math.min(rows.length, r + 10); rr++) {
                const value = Array.isArray(rows[rr]) ? rows[rr][idx] : '';
                if (isCode(value)) return clean(value).replace(/\.0$/, '');
            }
        }
    }

    return '';
}

function processUDISEData(rows, filename, showAlert = true) {
    if (!rows || rows.length === 0) {
        if (showAlert) alert('The uploaded file appears to be empty.');
        return;
    }

    let headerRowIdx = -1;
    for (let i = 0; i < Math.min(10, rows.length); i++) {
        const row = (rows[i] || []).map(cell => String(cell || '').trim().toLowerCase());
        if (row.includes('class') && (row.includes('gender') || row.includes('name') || row.includes('student name') || row.includes('social category'))) {
            headerRowIdx = i;
            break;
        }
    }

    if (headerRowIdx === -1) {
        if (showAlert) alert('Could not detect standard UDISE+ student columns (Class, Section, Gender, etc.).');
        return;
    }

    const headers = rows[headerRowIdx].map(h => String(h || '').trim());
    const dataRows = rows.slice(headerRowIdx + 1).filter(r => r && r.length > 0 && r.some(c => c !== null && c !== ''));

    globalStudents = dataRows.map(r => {
        let obj = {};
        headers.forEach((h, idx) => {
            let val = r[idx];
            if (val instanceof Date) {
                val = val.toISOString().split('T')[0];
            }
            obj[h] = val !== undefined && val !== null ? String(val).trim() : '';
        });
        return obj;
    });

    renderDashboard(globalStudents, filename);
}

function isMale(s) {
    const g = (s['Gender'] || '').toLowerCase();
    return g === 'male' || g === 'm';
}

function isFemale(s) {
    const g = (s['Gender'] || '').toLowerCase();
    return g === 'female' || g === 'f';
}

function isApaarDone(s) {
    const apaarStatus = (s['APAAR Status'] || '').trim().toLowerCase();
    const apaarId = (s['APAAR ID'] || '').trim().toLowerCase();
    return (apaarStatus === 'generated' || apaarStatus === 'auto generated') ||
           (apaarId !== '' && apaarId !== 'na' && apaarId !== 'null' && apaarId !== '-' && apaarId !== 'nan');
}

function getAadhaarKey(s) {
    const raw = (s['AADHAAR Validation Status'] || s['Aadhaar Validation Status'] || s['Aadhaar Status'] || '').toLowerCase();
    if (raw.includes('verified')) return 'Verified';
    if (raw.includes('failed')) return 'Validation failed';
    return 'Pending';
}

function getMbuKey(s) {
    const raw = (
        s['MBU Status'] ||
        s['MUB Status'] ||
        s['MBU'] ||
        s['Mandatory Biometric Update'] ||
        s['Mandatory Biometric Update (MBU) Status'] ||
        ''
    ).trim().toLowerCase();

    if (raw.includes('pending') || (raw.includes('required') && !raw.includes('not required'))) {
        return 'pending';
    } else if (raw.includes('completed') || raw.includes('updated') || raw.includes('done')) {
        return 'completed';
    }
    return 'not_required';
}

function getStudentName(s) {
    return s['Student Name'] || s['Name'] || s['Name of Student'] || s['Student'] || 'Unnamed';
}

function getStudentPEN(s) {
    return s['PEN'] || s['Permanent Education Number'] || s['Student PEN'] || s['PEN Number'] || '-';
}

function filterAndShow(title, predicate) {
    currentFilterTitle = title;
    currentFilteredList = globalStudents.filter(predicate);
    
    document.getElementById('modalTitle').innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        ${title} (${currentFilteredList.length} Students)
    `;
    const tbody = document.getElementById('modalTableBody');
    
    if (currentFilteredList.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; color: var(--text-muted); padding: 14px;">No student records found matching this criterion.</td></tr>`;
    } else {
        tbody.innerHTML = currentFilteredList.map((s, idx) => `
            <tr>
                <td><strong>${idx + 1}</strong></td>
                <td style="font-weight: 700;">${getStudentName(s)}</td>
                <td><strong>Class ${s['Class'] || '-'}</strong></td>
                <td>${s['Section'] || '-'}</td>
                <td>${s['DOB'] || s['Date of Birth'] || '-'}</td>
                <td>${s['Gender'] || '-'}</td>
                <td>${isApaarDone(s) ? '<span class="status-pill status-verified">Generated</span>' : '<span class="status-pill status-pending">Pending</span>'}</td>
                <td>${getMbuKey(s) === 'pending' ? '<span class="status-pill status-pending">Pending</span>' : (getMbuKey(s) === 'completed' ? '<span class="status-pill status-verified">Updated</span>' : '<span class="status-pill status-neutral">N/A</span>')}</td>
                <td>${getAadhaarKey(s) === 'Verified' ? '<span class="status-pill status-verified">Verified</span>' : (getAadhaarKey(s) === 'Validation failed' ? '<span class="status-pill status-failed">Failed</span>' : '<span class="status-pill status-pending">Pending</span>')}</td>
                <td class="no-print">
                    <button class="btn-text-list btn-list-primary" onclick="openSo3FormForStudent('${getStudentPEN(s)}')">Form S03</button>
                </td>
            </tr>
        `).join('');
    }

    document.getElementById('drillModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('drillModal').style.display = 'none';
}

function closeModalOnOutside(e) {
    if (e.target.id === 'drillModal') closeModal();
}

function printModalList() {
    document.body.classList.add('printing-modal');
    window.print();
    document.body.classList.remove('printing-modal');
}

function exportModalCSV() {
    if (!currentFilteredList || currentFilteredList.length === 0) {
        alert('No data to export.');
        return;
    }

    const keys = Object.keys(currentFilteredList[0]);
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += keys.map(k => `"${k.replace(/"/g, '""')}"`).join(',') + '\r\n';

    currentFilteredList.forEach(row => {
        const line = keys.map(k => `"${String(row[k] || '').replace(/"/g, '""')}"`).join(',');
        csvContent += line + '\r\n';
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${currentFilterTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_export.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function searchByPEN() {
    const query = document.getElementById('penSearchInput').value.trim().toLowerCase();
    if (!query) {
        alert('Please enter a PEN number to search.');
        return;
    }

    if (!globalStudents || globalStudents.length === 0) {
        alert('No student data loaded. Please upload a UDISE+ Excel spreadsheet first.');
        return;
    }

    const results = globalStudents.filter(s => {
        const penVal = String(getStudentPEN(s)).trim().toLowerCase();
        if (penVal.includes(query)) return true;
        return Object.values(s).some(val => 
            String(val).trim().toLowerCase().includes(query)
        );
    });

    if (results.length === 0) {
        alert(`No student found matching PEN: "${query}"`);
        return;
    }

    currentFilteredList = results;
    currentFilterTitle = `PEN Search Result: ${query}`;
    
    document.getElementById('modalTitle').innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        PEN Search: "${query}" (${results.length} Found)
    `;

    const tbody = document.getElementById('modalTableBody');
    tbody.innerHTML = results.map((s, idx) => `
        <tr>
            <td><strong>${idx + 1}</strong></td>
            <td style="font-weight: 700;">${getStudentName(s)}</td>
            <td><strong>Class ${s['Class'] || '-'}</strong></td>
            <td>${s['Section'] || '-'}</td>
            <td>${s['DOB'] || s['Date of Birth'] || '-'}</td>
            <td>${s['Gender'] || '-'}</td>
            <td>${isApaarDone(s) ? '<span class="status-pill status-verified">Generated</span>' : '<span class="status-pill status-pending">Pending</span>'}</td>
            <td>${getMbuKey(s) === 'pending' ? '<span class="status-pill status-pending">Pending</span>' : (getMbuKey(s) === 'completed' ? '<span class="status-pill status-verified">Updated</span>' : '<span class="status-pill status-neutral">N/A</span>')}</td>
            <td>${getAadhaarKey(s) === 'Verified' ? '<span class="status-pill status-verified">Verified</span>' : (getAadhaarKey(s) === 'Validation failed' ? '<span class="status-pill status-failed">Failed</span>' : '<span class="status-pill status-pending">Pending</span>')}</td>
            <td class="no-print">
                <button class="btn-text-list btn-list-primary" onclick="openSo3FormForStudent('${getStudentPEN(s)}')">Form S03</button>
            </td>
        </tr>
    `).join('');

    document.getElementById('drillModal').style.display = 'flex';

    if (results.length === 1) {
        openSo3FormForStudent(getStudentPEN(results[0]));
    }
}

function handlePenSearchKeyup(e) {
    if (e.key === 'Enter') {
        searchByPEN();
    }
}

function clearPenSearch() {
    document.getElementById('penSearchInput').value = '';
}

function openSo3FormForStudent(pen) {
    const student = globalStudents.find(s => String(getStudentPEN(s)).trim() === String(pen).trim());
    
    const codeFromExcel = uploadedUdiseCode || extractUdiseCodeFromRows(rawDataUdise) || '';
    document.getElementById('formUdiseCode').value = codeFromExcel;

    const ayEl = document.getElementById('formAcademicYear');
    const schEl = document.getElementById('formSchoolName');
    const blkEl = document.getElementById('formBlock');
    const stEl = document.getElementById('formState');
    const distEl = document.getElementById('formDistrict');

    if (!ayEl.value) ayEl.value = "";
    if (!schEl.value) schEl.value = "";
    if (!blkEl.value) blkEl.value = "";
    if (!stEl.value) stEl.value = "";
    if (!distEl.value) distEl.value = "";

    if (student) {
        document.getElementById('formStudentPen').value = getStudentPEN(student);
        document.getElementById('formStudentName').value = getStudentName(student);
        document.getElementById('formClassSec').value = `Class ${student['Class'] || '-'} - ${student['Section'] || '-'}`;
    } else {
        const query = document.getElementById('penSearchInput').value.trim();
        document.getElementById('formStudentPen').value = query || "";
        document.getElementById('formStudentName').value = query ? "Student (Searched)" : "";
        document.getElementById('formClassSec').value = "";
    }

    document.getElementById('so3FormModal').style.display = 'flex';
}

function printSo3Form() {
    document.body.classList.add('printing-so3');
    requestAnimationFrame(() => {
        window.print();
        setTimeout(() => document.body.classList.remove('printing-so3'), 300);
    });
}

function closeSo3FormModal() {
    document.getElementById('so3FormModal').style.display = 'none';
}

function closeSo3ModalOnOutside(e) {
    if (e.target.id === 'so3FormModal') closeSo3FormModal();
}

function renderDashboard(students, filename) {
    const total = students.length;
    if (total === 0) return;

    let boys = 0, girls = 0;
    let aadhaarVerified = 0, aadhaarFailed = 0, aadhaarPending = 0;
    let apaarGenerated = 0;
    let bplCount = 0;
    let cwsnCount = 0;
    let completedEntries = 0;

    let mbuPendingTotal = 0;
    let mbuCompletedTotal = 0;
    let mbuNotRequiredTotal = 0;

    const classMap = {};
    const categoriesFound = new Set();
    const classCategoryMap = {};
    const classesFound = new Set();
    const classApaarMap = {};
    const classMbuMap = {};

    const aadhaarApaarCrossMap = {
        'Verified': { total: 0, generated: 0, pending: 0, pill: 'status-verified' },
        'Validation failed': { total: 0, generated: 0, pending: 0, pill: 'status-failed' },
        'Pending': { total: 0, generated: 0, pending: 0, pill: 'status-pending' }
    };

    students.forEach(s => {
        if (isMale(s)) boys++;
        else if (isFemale(s)) girls++;

        const cls = s['Class'] || 'Unknown';
        const sec = s['Section'] || '-';
        const cat = s['Social Category'] || 'Not Specified';

        classesFound.add(cls);
        categoriesFound.add(cat);

        if (!classMap[cls]) classMap[cls] = {};
        if (!classMap[cls][sec]) classMap[cls][sec] = { boys: 0, girls: 0, total: 0 };

        if (isMale(s)) classMap[cls][sec].boys++;
        else if (isFemale(s)) classMap[cls][sec].girls++;
        classMap[cls][sec].total++;

        if (!classCategoryMap[cls]) classCategoryMap[cls] = {};
        classCategoryMap[cls][cat] = (classCategoryMap[cls][cat] || 0) + 1;

        if (!classApaarMap[cls]) classApaarMap[cls] = { total: 0, generated: 0, pending: 0 };
        classApaarMap[cls].total++;

        const isApaar = isApaarDone(s);
        if (isApaar) {
            apaarGenerated++;
            classApaarMap[cls].generated++;
        } else {
            classApaarMap[cls].pending++;
        }

        if (!classMbuMap[cls]) classMbuMap[cls] = { total: 0, pending: 0, completed: 0, notRequired: 0 };
        classMbuMap[cls].total++;

        const mbuKey = getMbuKey(s);
        if (mbuKey === 'pending') {
            mbuPendingTotal++;
            classMbuMap[cls].pending++;
        } else if (mbuKey === 'completed') {
            mbuCompletedTotal++;
            classMbuMap[cls].completed++;
        } else {
            mbuNotRequiredTotal++;
            classMbuMap[cls].notRequired++;
        }

        const aadhaarKey = getAadhaarKey(s);
        if (aadhaarKey === 'Verified') aadhaarVerified++;
        else if (aadhaarKey === 'Validation failed') aadhaarFailed++;
        else aadhaarPending++;

        if (!aadhaarApaarCrossMap[aadhaarKey]) {
            aadhaarApaarCrossMap[aadhaarKey] = { total: 0, generated: 0, pending: 0, pill: 'status-pending' };
        }
        aadhaarApaarCrossMap[aadhaarKey].total++;
        if (isApaar) aadhaarApaarCrossMap[aadhaarKey].generated++;
        else aadhaarApaarCrossMap[aadhaarKey].pending++;

        const bpl = (s['BPL beneficiary'] || '').toLowerCase();
        if (bpl === 'yes') bplCount++;

        const cwsn = (s['CWSN'] || '').toLowerCase();
        if (cwsn === 'yes') cwsnCount++;

        const entryStatus = (s['Entry Status'] || '').toLowerCase();
        if (entryStatus.includes('completed')) completedEntries++;
    });

    document.getElementById('reportSub').innerHTML = `File: <strong>${filename}</strong>`;
    const classList = Array.from(classesFound);
    document.getElementById('classesBadge').textContent = `Classes: ${classList.join(', ')}`;
    document.getElementById('totalActiveBadge').textContent = `Total: ${total}`;

    document.getElementById('kpiTotal').textContent = total;
    document.getElementById('kpiBoys').textContent = boys;
    document.getElementById('kpiBoysPct').textContent = `${((boys / total) * 100).toFixed(1)}%`;
    document.getElementById('kpiGirls').textContent = girls;
    document.getElementById('kpiGirlsPct').textContent = `${((girls / total) * 100).toFixed(1)}%`;
    document.getElementById('kpiAadhaar').textContent = aadhaarVerified;
    document.getElementById('kpiAadhaarPct').textContent = `${((aadhaarVerified / total) * 100).toFixed(1)}%`;
    document.getElementById('kpiMbuPending').textContent = mbuPendingTotal;
    document.getElementById('kpiMbuPendingPct').textContent = `${((mbuPendingTotal / total) * 100).toFixed(1)}%`;
    document.getElementById('kpiApaar').textContent = apaarGenerated;
    document.getElementById('kpiApaarPct').textContent = `${((apaarGenerated / total) * 100).toFixed(1)}%`;
    document.getElementById('kpiBpl').textContent = bplCount;
    document.getElementById('kpiBplPct').textContent = `${((bplCount / total) * 100).toFixed(1)}%`;

    const classTableBody = document.getElementById('classSectionTableBody');
    let classTableHTML = '';
    Object.keys(classMap).forEach(cls => {
        let classBoys = 0, classGirls = 0, classTotal = 0;
        Object.keys(classMap[cls]).forEach(sec => {
            const item = classMap[cls][sec];
            classBoys += item.boys;
            classGirls += item.girls;
            classTotal += item.total;
            classTableHTML += `
                <tr>
                    <td><strong>Class ${cls}</strong></td>
                    <td><strong>${sec}</strong></td>
                    <td>
                        <div class="cell-flex">
                            <span>${item.boys}</span>
                            <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} Sec ${sec} - Boys', s => s['Class'] === '${cls}' && (s['Section']||'-') === '${sec}' && isMale(s))">List</button>
                        </div>
                    </td>
                    <td>
                        <div class="cell-flex">
                            <span>${item.girls}</span>
                            <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} Sec ${sec} - Girls', s => s['Class'] === '${cls}' && (s['Section']||'-') === '${sec}' && isFemale(s))">List</button>
                        </div>
                    </td>
                    <td>
                        <div class="cell-flex">
                            <strong>${item.total}</strong>
                            <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('Class ${cls} Sec ${sec} - Total', s => s['Class'] === '${cls}' && (s['Section']||'-') === '${sec}')">List</button>
                        </div>
                    </td>
                </tr>
            `;
        });
        classTableHTML += `
            <tr class="subtotal-row">
                <td colspan="2"><strong>Subtotal Class ${cls}</strong></td>
                <td>
                    <div class="cell-flex">
                        <strong>${classBoys}</strong>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - All Boys', s => s['Class'] === '${cls}' && isMale(s))">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <strong>${classGirls}</strong>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - All Girls', s => s['Class'] === '${cls}' && isFemale(s))">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <strong>${classTotal}</strong>
                        <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('Class ${cls} - All Students', s => s['Class'] === '${cls}')">List</button>
                    </div>
                </td>
            </tr>
        `;
    });
    classTableHTML += `
        <tr class="total-row">
            <td colspan="2">Grand Total</td>
            <td>
                <div class="cell-flex">
                    <span>${boys}</span>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All Boys', s => isMale(s))">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <span>${girls}</span>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All Girls', s => isFemale(s))">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${total}</strong>
                    <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button>
                </div>
            </td>
        </tr>
    `;
    classTableBody.innerHTML = classTableHTML;

    const mbuTableBody = document.getElementById('mbuSummaryTableBody');
    let mbuTableHTML = '';
    classList.forEach(cls => {
        const data = classMbuMap[cls] || { total: 0, pending: 0, completed: 0, notRequired: 0 };
        const pendingRate = data.total > 0 ? ((data.pending / data.total) * 100).toFixed(1) : "0.0";
        mbuTableHTML += `
            <tr>
                <td><strong>Class ${cls}</strong></td>
                <td>
                    <div class="cell-flex">
                        <strong>${data.total}</strong>
                        <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('Class ${cls} - Total Students', s => s['Class'] === '${cls}')">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-pending">${data.pending}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - MBU Pending', s => s['Class'] === '${cls}' && getMbuKey(s) === 'pending')">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-verified">${data.completed}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - MBU Updated', s => s['Class'] === '${cls}' && getMbuKey(s) === 'completed')">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-neutral">${data.notRequired}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - MBU N/A', s => s['Class'] === '${cls}' && getMbuKey(s) === 'not_required')">List</button>
                    </div>
                </td>
                <td><strong>${pendingRate}%</strong></td>
            </tr>
        `;
    });

    const overallMbuPendingRate = ((mbuPendingTotal / total) * 100).toFixed(1);
    mbuTableHTML += `
        <tr class="total-row">
            <td>Grand Total</td>
            <td>
                <div class="cell-flex">
                    <strong>${total}</strong>
                    <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${mbuPendingTotal}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All MBU Pending', s => getMbuKey(s) === 'pending')">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${mbuCompletedTotal}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All MBU Completed', s => getMbuKey(s) === 'completed')">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${mbuNotRequiredTotal}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All MBU N/A', s => getMbuKey(s) === 'not_required')">List</button>
                </div>
            </td>
            <td><strong>${overallMbuPendingRate}%</strong></td>
        </tr>
    `;
    mbuTableBody.innerHTML = mbuTableHTML;

    const mbuBadgeEl = document.getElementById('mbuOverallBadge');
    mbuBadgeEl.textContent = `${mbuPendingTotal}/${total} (${overallMbuPendingRate}%)`;
    mbuBadgeEl.className = `status-pill ${mbuPendingTotal > 0 ? 'status-pending' : 'status-verified'}`;

    const apaarTableBody = document.getElementById('apaarSummaryTableBody');
    let apaarTableHTML = '';
    let totalApaarPending = total - apaarGenerated;

    classList.forEach(cls => {
        const data = classApaarMap[cls] || { total: 0, generated: 0, pending: 0 };
        const rate = data.total > 0 ? ((data.generated / data.total) * 100).toFixed(1) : "0.0";
        apaarTableHTML += `
            <tr>
                <td><strong>Class ${cls}</strong></td>
                <td>
                    <div class="cell-flex">
                        <strong>${data.total}</strong>
                        <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('Class ${cls} - Total Students', s => s['Class'] === '${cls}')">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-verified">${data.generated}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - APAAR Generated', s => s['Class'] === '${cls}' && isApaarDone(s))">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-pending">${data.pending}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - APAAR Pending', s => !isApaarDone(s))">List</button>
                    </div>
                </td>
                <td><strong>${rate}%</strong></td>
            </tr>
        `;
    });

    const overallApaarRate = ((apaarGenerated / total) * 100).toFixed(1);
    apaarTableHTML += `
        <tr class="total-row">
            <td>Grand Total</td>
            <td>
                <div class="cell-flex">
                    <strong>${total}</strong>
                    <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${apaarGenerated}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Generated', s => isApaarDone(s))">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${totalApaarPending}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Pending', s => !isApaarDone(s))">List</button>
                </div>
            </td>
            <td><strong>${overallApaarRate}%</strong></td>
        </tr>
    `;
    apaarTableBody.innerHTML = apaarTableHTML;

    const badgeEl = document.getElementById('apaarOverallBadge');
    badgeEl.textContent = `${apaarGenerated}/${total} (${overallApaarRate}%)`;
    badgeEl.className = `status-pill ${overallApaarRate > 50 ? 'status-verified' : 'status-pending'}`;

    const aadhaarCrossTableBody = document.getElementById('apaarAadhaarTableBody');
    let crossHTML = '';
    ['Verified', 'Validation failed', 'Pending'].forEach(statusKey => {
        const rowData = aadhaarApaarCrossMap[statusKey] || { total: 0, generated: 0, pending: 0, pill: 'status-pending' };
        const convRate = rowData.total > 0 ? ((rowData.generated / rowData.total) * 100).toFixed(1) : "0.0";
        crossHTML += `
            <tr>
                <td><span class="status-pill ${rowData.pill}">${statusKey}</span></td>
                <td>
                    <div class="cell-flex">
                        <strong>${rowData.total}</strong>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar ${statusKey} Students', s => getAadhaarKey(s) === '${statusKey}')">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-verified">${rowData.generated}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar ${statusKey} & APAAR Generated', s => getAadhaarKey(s) === '${statusKey}' && isApaarDone(s))">List</button>
                    </div>
                </td>
                <td>
                    <div class="cell-flex">
                        <span class="status-pill status-pending">${rowData.pending}</span>
                        <button class="btn-text-list no-print" onclick="filterAndShow('Aadhaar ${statusKey} & APAAR Pending', s => getAadhaarKey(s) === '${statusKey}' && !isApaarDone(s))">List</button>
                    </div>
                </td>
                <td><strong>${convRate}%</strong></td>
            </tr>
        `;
    });
    crossHTML += `
        <tr class="total-row">
            <td>Grand Total</td>
            <td>
                <div class="cell-flex">
                    <strong>${total}</strong>
                    <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${apaarGenerated}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Generated', s => isApaarDone(s))">List</button>
                </div>
            </td>
            <td>
                <div class="cell-flex">
                    <strong>${totalApaarPending}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('All APAAR Pending', s => !isApaarDone(s))">List</button>
                </div>
            </td>
            <td><strong>${overallApaarRate}%</strong></td>
        </tr>
    `;
    aadhaarCrossTableBody.innerHTML = crossHTML;

    const categoryTableBody = document.getElementById('socialCategoryTableBody');
    const categoryTableHead = document.getElementById('socialCategoryTableHead');
    const categories = Array.from(categoriesFound);
    
    let headHTML = '<tr><th>Category</th>';
    classList.forEach(cls => {
        headHTML += `<th>Class ${cls}</th>`;
    });
    headHTML += '<th>Total</th></tr>';
    categoryTableHead.innerHTML = headHTML;

    let catHTML = '';
    categories.forEach(cat => {
        let rowTotal = 0;
        let cellsHTML = '';
        classList.forEach(cls => {
            const count = (classCategoryMap[cls] && classCategoryMap[cls][cat]) || 0;
            rowTotal += count;
            cellsHTML += `
                <td>
                    <div class="cell-flex">
                        <span>${count}</span>
                        ${count > 0 ? `<button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} - ${cat}', s => s['Class'] === '${cls}' && (s['Social Category']||'Not Specified') === '${cat}')">List</button>` : ''}
                    </div>
                </td>
            `;
        });
        catHTML += `
            <tr>
                <td><strong>${cat}</strong></td>
                ${cellsHTML}
                <td>
                    <div class="cell-flex">
                        <strong>${rowTotal}</strong>
                        <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All ${cat}', s => (s['Social Category']||'Not Specified') === '${cat}')">List</button>
                    </div>
                </td>
            </tr>
        `;
    });

    let catFooterCells = '';
    classList.forEach(cls => {
        let totalInClass = 0;
        categories.forEach(cat => {
            totalInClass += (classCategoryMap[cls] && classCategoryMap[cls][cat]) || 0;
        });
        catFooterCells += `
            <td>
                <div class="cell-flex">
                    <strong>${totalInClass}</strong>
                    <button class="btn-text-list no-print" onclick="filterAndShow('Class ${cls} Students', s => s['Class'] === '${cls}')">List</button>
                </div>
            </td>
        `;
    });
    catHTML += `
        <tr class="total-row">
            <td>Grand Total</td>
            ${catFooterCells}
            <td>
                <div class="cell-flex">
                    <strong>${total}</strong>
                    <button class="btn-text-list btn-list-primary no-print" onclick="filterAndShow('All Students', () => true)">List</button>
                </div>
            </td>
        </tr>
    `;
    categoryTableBody.innerHTML = catHTML;

    const complianceTableBody = document.getElementById('complianceTableBody');
    complianceTableBody.innerHTML = `
        <tr>
            <td><strong>Aadhaar Verified</strong></td>
            <td><strong>${aadhaarVerified}</strong></td>
            <td><span class="status-pill status-verified">Verified</span></td>
            <td class="no-print">
                <button class="btn-text-list" onclick="filterAndShow('Aadhaar Verified Students', s => getAadhaarKey(s) === 'Verified')">List</button>
            </td>
        </tr>
        <tr>
            <td><strong>Aadhaar Failed</strong></td>
            <td><strong>${aadhaarFailed}</strong></td>
            <td><span class="status-pill status-failed">Failed</span></td>
            <td class="no-print">
                <button class="btn-text-list" onclick="filterAndShow('Aadhaar Failed Students', s => getAadhaarKey(s) === 'Validation failed')">List</button>
            </td>
        </tr>
        <tr>
            <td><strong>Aadhaar Pending</strong></td>
            <td><strong>${aadhaarPending}</strong></td>
            <td><span class="status-pill status-pending">Pending</span></td>
            <td class="no-print">
                <button class="btn-text-list" onclick="filterAndShow('Aadhaar Pending Students', s => getAadhaarKey(s) === 'Pending')">List</button>
            </td>
        </tr>
        <tr>
            <td><strong>MBU Pending</strong></td>
            <td><strong>${mbuPendingTotal} / ${total}</strong></td>
            <td><span class="status-pill ${mbuPendingTotal > 0 ? 'status-pending' : 'status-verified'}">${((mbuPendingTotal / total) * 100).toFixed(1)}%</span></td>
            <td class="no-print">
                <button class="btn-text-list" onclick="filterAndShow('MBU Pending Students', s => getMbuKey(s) === 'pending')">List</button>
            </td>
        </tr>
        <tr>
            <td><strong>CWSN Students</strong></td>
            <td><strong>${cwsnCount}</strong></td>
            <td>Recorded</td>
            <td class="no-print">
                <button class="btn-text-list" onclick="filterAndShow('CWSN Students', s => (s['CWSN']||'').toLowerCase() === 'yes')">List</button>
            </td>
        </tr>
        <tr>
            <td><strong>BPL Beneficiaries</strong></td>
            <td><strong>${bplCount} / ${total}</strong></td>
            <td>${((bplCount / total) * 100).toFixed(1)}%</td>
            <td class="no-print">
                <button class="btn-text-list" onclick="filterAndShow('BPL Beneficiaries', s => (s['BPL beneficiary']||'').toLowerCase() === 'yes')">List</button>
            </td>
        </tr>
        <tr class="total-row">
            <td><strong>Entry Status Done</strong></td>
            <td><strong>${completedEntries} / ${total}</strong></td>
            <td>${total - completedEntries} Incomplete</td>
            <td class="no-print">
                <button class="btn-text-list btn-list-primary" onclick="filterAndShow('Completed Entries', s => (s['Entry Status']||'').toLowerCase().includes('completed'))">List</button>
            </td>
        </tr>
    `;
}

function toggleSidebar() {
    const sidebar = document.getElementById('appSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (!sidebar) return;
    sidebar.classList.toggle('open');
    if (overlay) overlay.classList.toggle('show');
}