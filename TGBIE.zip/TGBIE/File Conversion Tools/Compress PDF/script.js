 // 1. Block Context Menu
    document.addEventListener('contextmenu', e => e.preventDefault());

    // 2. Block Keyboard Inspection Shortcuts
    document.addEventListener('keydown', function(e) {
      if (e.key === 'F12' || e.keyCode === 123) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'i' || e.key === 'I' || e.keyCode === 73)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'j' || e.key === 'J' || e.keyCode === 74)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'c' || e.key === 'C' || e.keyCode === 67)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) { e.preventDefault(); return false; }
    });

    // 3. DevTools Debugger Trap (Freezes execution if DevTools is forced open)
    (function antiDebug() {
      setInterval(function() {
        const start = Date.now();
        (function() {}["constructor"]("debugger")());
        if (Date.now() - start > 100) {
          document.body.innerHTML = '<h2 style="color:red;text-align:center;margin-top:20%;">Developer Tools are restricted. Please close the console and reload.</h2>';
        }
      }, 1000);
    })();



// Live Date and Time Updater
function updateClock() {
    const now = new Date();
    const options = { 
        day: 'numeric', 
        month: 'short', 
        year: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        hour12: true 
    };
    let dateString = now.toLocaleString('en-US', options).replace(',', '');
    const clockElement = document.getElementById('clockText');
    if (clockElement) {
        clockElement.innerText = dateString;
    }
}
setInterval(updateClock, 1000);
updateClock();

pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

function formatSize(bytes){
    if(bytes < 1024) return bytes + " Bytes";
    if(bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB";
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
}

function showFileInfo(){
    const input = document.getElementById("pdfInput");
    const fileInfo = document.getElementById("fileInfo");

    if(!input.files.length){
        fileInfo.innerHTML = "";
        return;
    }

    const file = input.files[0];

    if(file.size > 50 * 1024 * 1024){
        fileInfo.innerHTML = "❌ Maximum supported file size is 50 MB.";
        return;
    }

    fileInfo.innerHTML = "✓ " + file.name + " (" + formatSize(file.size) + ")";
}

async function compressPDF(){
    const input = document.getElementById("pdfInput");
    const button = document.getElementById("compressBtn");
    const status = document.getElementById("status");
    const progressContainer = document.getElementById("progressContainer");
    const progressBar = document.getElementById("progressBar");
    const progressText = document.getElementById("progressText");

    if(!input.files.length){
        status.className = "error";
        status.innerHTML = "Please select a PDF file.";
        return;
    }

    const file = input.files[0];
    const targetSize = parseInt(document.getElementById("sizeLimit").value);

    if(file.size > 50 * 1024 * 1024){
        status.className = "error";
        status.innerHTML = "Maximum input size is 50 MB.";
        return;
    }

    if(file.size <= targetSize){
        downloadFile(file);
        status.className = "success";
        status.innerHTML = "✓ The PDF is already within the selected size.<br>File Size: " + formatSize(file.size);
        return;
    }

    button.disabled = true;
    button.innerHTML = "Processing...";
    progressContainer.style.display = "block";

    try{
        const data = await file.arrayBuffer();
        const pdfDocument = await pdfjsLib.getDocument({data: data}).promise;
        const totalPages = pdfDocument.numPages;

        let quality;
        let scale;

        if(targetSize <= 512000){ quality = 0.30; scale = 0.55; }
        else if(targetSize <= 1048576){ quality = 0.40; scale = 0.65; }
        else if(targetSize <= 2097152){ quality = 0.50; scale = 0.75; }
        else if(targetSize <= 5242880){ quality = 0.60; scale = 0.90; }
        else { quality = 0.75; scale = 1.10; }

        let outputPDF = null;

        for(let pageNumber = 1; pageNumber <= totalPages; pageNumber++){
            const progress = Math.round((pageNumber / totalPages) * 90);
            progressBar.style.width = progress + "%";
            progressText.innerHTML = progress + "%";
            status.innerHTML = "Processing page " + pageNumber + " of " + totalPages;

            await new Promise(resolve => setTimeout(resolve, 10));

            const page = await pdfDocument.getPage(pageNumber);
            const viewport = page.getViewport({scale: scale});
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d", {alpha: false});

            const maxDimension = 1600;
            let width = viewport.width;
            let height = viewport.height;

            if(width > maxDimension || height > maxDimension){
                const ratio = Math.min(maxDimension / width, maxDimension / height);
                width = width * ratio;
                height = height * ratio;
            }

            canvas.width = Math.floor(width);
            canvas.height = Math.floor(height);

            const renderScale = canvas.width / page.getViewport({scale: 1}).width;
            const finalViewport = page.getViewport({scale: renderScale});

            await page.render({
                canvasContext: context,
                viewport: finalViewport
            }).promise;

            const imageData = canvas.toDataURL("image/jpeg", quality);
            const orientation = canvas.width > canvas.height ? "landscape" : "portrait";

            if(pageNumber === 1){
                outputPDF = new jspdf.jsPDF({
                    orientation: orientation,
                    unit: "px",
                    format: [canvas.width, canvas.height],
                    compress: true
                });
            } else {
                outputPDF.addPage([canvas.width, canvas.height], orientation);
            }

            outputPDF.addImage(imageData, "JPEG", 0, 0, canvas.width, canvas.height, undefined, "FAST");

            canvas.width = 1;
            canvas.height = 1;
            page.cleanup();
        }

        progressBar.style.width = "95%";
        progressText.innerHTML = "Creating compressed PDF...";

        const blob = outputPDF.output("blob");

        progressBar.style.width = "100%";
        progressText.innerHTML = "100%";

        downloadBlob(blob, "NewGen-Compressed-PDF.pdf");

        button.disabled = false;
        button.innerHTML = "Compress PDF";
        status.className = "success";
        status.innerHTML = "✓ Compression Completed Successfully!<br><br>" +
        "Original Size: " + formatSize(file.size) + "<br>" +
        "Compressed Size: " + formatSize(blob.size) + "<br>" +
        "Selected Target: " + formatSize(targetSize);

        pdfDocument.cleanup();
        pdfDocument.destroy();

    } catch(error){
        console.error(error);
        button.disabled = false;
        button.innerHTML = "Compress PDF";
        status.className = "error";
        status.innerHTML = "Unable to process this PDF. For browser processing, try a PDF below 50 MB or with fewer pages.";
    }
}

function downloadBlob(blob, name){
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 3000);
}

function downloadFile(file){
    const url = URL.createObjectURL(file);
    const link = document.createElement("a");
    link.href = url;
    link.download = "NewGen-PDF.pdf";
    document.body.appendChild(link);
    link.click();
    link.remove();
}