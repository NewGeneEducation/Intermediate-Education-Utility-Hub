 // 1. Block Context Menu
    document.addEventListener('contextmenu', e => e.preventDefault());

    // 2. Block Keyboard Inspection Shortcuts
    document.addEventListener('keydown', function(e) {
      if (e.key === 'F12' || e.keyCode === 123) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'i' || e.key === 'I' || e.keyCode === 73)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'j' || e.key === 'J' || e.keyCode === 74)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'c' || e.key === 'C' || e.keyCode === 67)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) { e.preventDefault(); return false; }
    });

    // 3. DevTools Debugger Trap (Freezes execution if DevTools is forced open)
    (function antiDebug() {
      setInterval(function() {
        const start = Date.now();
        (function() {}["constructor"]("debugger")());
        if (Date.now() - start > 100) {
          document.body.innerHTML = '<h2 style="color:red;text-align:center;margin-top:20%;">Developer Tools are restricted. Please close the console and reload.</h2>';
        }
      }, 1000);
    })();



// Live Date and Time Updater
function updateClock() {
    const now = new Date();
    const options = { 
        day: 'numeric', 
        month: 'short', 
        year: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        hour12: true 
    };
    let dateString = now.toLocaleString('en-US', options).replace(',', '');
    const clockElement = document.getElementById('clockText');
    if (clockElement) {
        clockElement.innerText = dateString;
    }
}
setInterval(updateClock, 1000);
updateClock();

pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

async function convertPDF(){
 const input = document.getElementById("pdfFile");
 const format = document.getElementById("imageFormat").value;
 const status = document.getElementById("pdfStatus");
 const results = document.getElementById("pdfResults");
 results.innerHTML = "";
 
 if(!input.files.length){
     alert("Please select a PDF file.");
     return;
 }
 
 status.innerText = "Reading PDF...";
 try{
  const pdf = await pdfjsLib.getDocument({data: await input.files[0].arrayBuffer()}).promise;
  status.innerText = "Converting " + pdf.numPages + " page(s)...";
  
  for(let i = 1; i <= pdf.numPages; i++){
   const page = await pdf.getPage(i);
   const viewport = page.getViewport({scale: 2});
   const canvas = document.createElement("canvas");
   const context = canvas.getContext("2d");
   canvas.width = viewport.width;
   canvas.height = viewport.height;
   
   await page.render({canvasContext: context, viewport}).promise;
   
   const mime = format === "png" ? "image/png" : "image/jpeg";
   const ext = format === "png" ? "png" : "jpg";
   const data = canvas.toDataURL(mime, .92);
   
   const item = document.createElement("div");
   item.className = "preview-item";
   item.innerHTML = '<img src="' + data + '"><p>PDF Page ' + i + '</p><a class="download" href="' + data + '" download="page-' + i + '.' + ext + '">Download ' + ext.toUpperCase() + '</a>';
   results.appendChild(item);
  }
  status.innerText = "✓ PDF converted successfully.";
 }catch(e){
  console.error(e);
  status.innerText = "Unable to convert this PDF.";
 }
}

async function convertImagesToPDF(){
 const input = document.getElementById("imageFiles");
 const status = document.getElementById("imageStatus");
 const preview = document.getElementById("imagePreview");
 preview.innerHTML = "";
 
 if(!input.files.length){
     alert("Please select JPG or PNG images.");
     return;
 }
 
 status.innerText = "Creating PDF...";
 try{
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF({orientation: "portrait", unit: "mm", format: "a4"});
  
  for(let i = 0; i < input.files.length; i++){
   const file = input.files[i];
   const data = await readImage(file);
   const img = await loadImage(data);
   
   const pageW = 210, pageH = 297, margin = 10;
   const maxW = pageW - margin * 2;
   const maxH = pageH - margin * 2;
   let w = img.width, h = img.height;
   const ratio = Math.min(maxW / w, maxH / h);
   w *= ratio;
   h *= ratio;
   
   if(i > 0) pdf.addPage();
   pdf.addImage(data, file.type === "image/png" ? "PNG" : "JPEG", (pageW - w) / 2, (pageH - h) / 2, w, h);
   
   const item = document.createElement("div");
   item.className = "preview-item";
   item.innerHTML = '<img src="' + data + '"><p>' + file.name + '</p>';
   preview.appendChild(item);
  }
  
  pdf.save("NewGen-eEducation-Images.pdf");
  status.innerText = "✓ PDF created successfully.";
 }catch(e){
  console.error(e);
  status.innerText = "Unable to create PDF.";
 }
}

function readImage(file){
    return new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(file);
    });
}

function loadImage(src){
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
    });
}