 // 1. Block Context Menu
    document.addEventListener('contextmenu', e => e.preventDefault());

    // 2. Block Keyboard Inspection Shortcuts
    document.addEventListener('keydown', function(e) {
      if (e.key === 'F12' || e.keyCode === 123) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'i' || e.key === 'I' || e.keyCode === 73)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'j' || e.key === 'J' || e.keyCode === 74)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'c' || e.key === 'C' || e.keyCode === 67)) { e.preventDefault(); return false; }
      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) { e.preventDefault(); return false; }
    });

    // 3. DevTools Debugger Trap (Freezes execution if DevTools is forced open)
    (function antiDebug() {
      setInterval(function() {
        const start = Date.now();
        (function() {}["constructor"]("debugger")());
        if (Date.now() - start > 100) {
          document.body.innerHTML = '<h2 style="color:red;text-align:center;margin-top:20%;">Developer Tools are restricted. Please close the console and reload.</h2>';
        }
      }, 1000);
    })();



// Live Date and Time Updater
function updateClock() {
    const now = new Date();
    const options = { 
        day: 'numeric', 
        month: 'short', 
        year: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        hour12: true 
    };
    let dateString = now.toLocaleString('en-US', options).replace(',', '');
    const clockElement = document.getElementById('clockText');
    if (clockElement) {
        clockElement.innerText = dateString;
    }
}
setInterval(updateClock, 1000);
updateClock();

let selectedImage = null;

/* Format File Size[cite: 2] */
function formatSize(bytes) {
    if (bytes < 1024) {
        return bytes + " Bytes";
    }
    return (bytes / 1024).toFixed(2) + " KB";
}

/* Show Image Information[cite: 2] */
function showImageInfo() {
    const input = document.getElementById("imageInput");
    const fileInfo = document.getElementById("fileInfo");
    const previewBox = document.getElementById("previewBox");
    const preview = document.getElementById("imagePreview");

    if (!input.files.length) {
        fileInfo.style.display = "none";
        previewBox.style.display = "none";
        selectedImage = null;
        return;
    }

    const file = input.files[0];
    selectedImage = file;
    fileInfo.style.display = "block";
    fileInfo.innerHTML = "✓ " + file.name + "<br>Original Size: " + formatSize(file.size);

    const reader = new FileReader();
    reader.onload = function(event) {
        preview.src = event.target.result;
        previewBox.style.display = "block";
    };
    reader.readAsDataURL(file);
}

/* Main Compression Function[cite: 2] */
async function compressImage() {
    const input = document.getElementById("imageInput");
    const targetSize = parseInt(document.getElementById("targetSize").value);
    const button = document.getElementById("compressBtn");
    const status = document.getElementById("status");
    const progressBox = document.getElementById("progressBox");
    const progressFill = document.getElementById("progressFill");
    const progressText = document.getElementById("progressText");

    if (!input.files.length) {
        status.className = "error";
        status.innerHTML = "Please select a photo.";
        return;
    }

    const file = input.files[0];

    if (file.size > 25 * 1024 * 1024) {
        status.className = "error";
        status.innerHTML = "Please select an image below 25 MB.";
        return;
    }

    button.disabled = true;
    button.innerHTML = "Compressing...";
    progressBox.style.display = "block";
    progressFill.style.width = "10%[cite: 2]";
    progressText.innerHTML = "Loading image...[cite: 2]";

    try {
        const image = new Image();
        const imageURL = URL.createObjectURL(file);
        image.src = imageURL;

        await new Promise(function(resolve, reject) {
            image.onload = resolve;
            image.onerror = reject;
        });

        progressFill.style.width = "25%[cite: 2]";
        progressText.innerHTML = "Preparing photo...[cite: 2]";

        let width = image.naturalWidth;
        let height = image.naturalHeight;
        const maxDimension = 2500;

        if (width > maxDimension || height > maxDimension) {
            const ratio = Math.min(maxDimension / width, maxDimension / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
        }

        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");
        let quality = 0.90;
        let bestBlob = null;
        let attempt = 0;

        while (attempt < 12) {
            canvas.width = width;
            canvas.height = height;
            context.drawImage(image, 0, 0, width, height);

            progressFill.style.width = (30 + attempt * 5) + "%";
            progressText.innerHTML = "Compressing... Attempt " + (attempt + 1);

            const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", quality));

            if (!bestBlob || blob.size < bestBlob.size) {
                bestBlob = blob;
            }

            if (blob.size <= targetSize) {
                break;
            }

            quality -= 0.10;

            if (quality < 0.20) {
                quality = 0.80;
                width = Math.round(width * 0.75);
                height = Math.round(height * 0.75);
            }

            if (width < 100 || height < 100) {
                break;
            }

            attempt++;
            await new Promise(resolve => setTimeout(resolve, 20));
        }

        progressFill.style.width = "100%";
        progressText.innerHTML = "Completed";
        URL.revokeObjectURL(imageURL);
        canvas.width = 1;
        canvas.height = 1;

        if (!bestBlob) {
            throw new Error("Compression failed");
        }

        const url = URL.createObjectURL(bestBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "NewGen-Compressed-Photo.jpg";
        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(function() {
            URL.revokeObjectURL(url);
        }, 2000);

        button.disabled = false;
        button.innerHTML = "Compress & Download Photo";

        if (bestBlob.size <= targetSize) {
            status.className = "success";
            status.innerHTML = "✓ Photo Compressed Successfully!<br><br>" +
                "Original Size: " + formatSize(file.size) + "<br>" +
                "Compressed Size: " + formatSize(bestBlob.size);
        } else {
            status.className = "error";
            status.innerHTML = "Compression completed, but the selected target could not be reached.<br><br>" +
                "Original Size: " + formatSize(file.size) + "<br>" +
                "Best Result: " + formatSize(bestBlob.size);
        }

    } catch (error) {
        console.error(error);
        button.disabled = false;
        button.innerHTML = "Compress & Download Photo";
        status.className = "error";
        status.innerHTML = "Unable to process this image. Please try another photo.";
    }
}